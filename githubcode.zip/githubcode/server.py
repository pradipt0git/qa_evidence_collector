"""Capture Assist - local web dashboard (standard library HTTP server)."""
import json
import re
import mimetypes
import os
import subprocess
import sys
import threading
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote, unquote, urlparse

from recorder import Recorder, new_meta, slugify, write_json

BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "web"
EXEC_DIR = BASE_DIR / "executions"
mimetypes.add_type("video/webm", ".webm")
mimetypes.add_type("application/vnd.openxmlformats-officedocument.wordprocessingml.document", ".docx")


def normalize_url(url):
    """Add a scheme when missing: http for local/intranet hosts and IPs, https otherwise."""
    if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", url):
        return url
    host = re.split(r"[:/?#]", url, maxsplit=1)[0].lower()
    local = host == "localhost" or "." not in host or re.fullmatch(r"[\d.]+", host)
    return ("http://" if local else "https://") + url


class App:
    def __init__(self):
        EXEC_DIR.mkdir(exist_ok=True)
        self.lock = threading.Lock()
        self.active = None
        self._recover_interrupted()

    def _recover_interrupted(self):
        """Runs left 'recording' by a crash/close: rebuild the doc from events.jsonl."""
        for meta_path in EXEC_DIR.glob("*/meta.json"):
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
            except Exception:
                continue
            if meta.get("status") not in ("recording", "generating"):
                continue
            d = meta_path.parent
            meta["status"] = "interrupted"
            meta["videos"] = [f"video/{p.name}" for p in (d / "video").glob("*.webm") if p.stat().st_size > 0]
            try:
                from report import build_report
                events = []
                ev_file = d / "events.jsonl"
                if ev_file.exists():
                    for line in ev_file.read_text(encoding="utf-8").splitlines():
                        try:
                            events.append(json.loads(line))
                        except Exception:
                            pass
                events.sort(key=lambda e: (e.get("ts") or 0, e.get("step") or 0))
                meta["steps"] = sum(1 for e in events if e.get("kind") == "snapshot")
                meta["doc"] = build_report(d, meta, events)
            except Exception as e:
                meta["error"] = f"Recovery failed: {e}"
            write_json(meta_path, meta)

    # ------------------------------------------------------------------ API
    def list(self):
        items = []
        for meta_path in EXEC_DIR.glob("*/meta.json"):
            try:
                items.append(json.loads(meta_path.read_text(encoding="utf-8")))
            except Exception:
                pass
        rec = self.active
        if rec and rec.is_alive():
            items = [rec.live() if m.get("id") == rec.meta["id"] else m for m in items]
        items.sort(key=lambda m: m.get("started") or "", reverse=True)
        return items

    def get(self, exec_id):
        rec = self.active
        if rec and rec.meta["id"] == exec_id:
            return rec.live()
        p = EXEC_DIR / exec_id / "meta.json"
        if p.is_file() and p.resolve().parent.parent == EXEC_DIR.resolve():
            return json.loads(p.read_text(encoding="utf-8"))
        return None

    def previous_runs(self, tc_name, exclude=None):
        """Earlier executions of the same test case (name compared case/space-insensitively)."""
        key = " ".join((tc_name or "").split()).lower()
        return [m for m in self.list()
                if " ".join((m.get("tc_name") or "").split()).lower() == key and m.get("id") != exclude
                and m.get("status") in ("completed", "interrupted") and (EXEC_DIR / m["id"] / "events.jsonl").exists()]

    def start(self, tc_name, url, script=None, baseline="auto"):
        tc_name = (tc_name or "").strip()
        url = (url or "").strip()
        if not tc_name:
            raise ValueError("Test case name is required.")
        if not url:
            raise ValueError("Launch URL is required.")
        url = normalize_url(url)
        if urlparse(url).scheme not in ("http", "https", "file"):
            raise ValueError("URL must start with http:// or https://")
        with self.lock:
            if self.active and self.active.is_alive():
                raise RuntimeError("Another execution is still running. Close its browser window first.")
            prev = self.previous_runs(tc_name)
            if baseline in (None, "auto"):
                baseline_id = prev[0]["id"] if prev else None          # latest earlier run
            elif baseline in ("", "none"):
                baseline_id = None
            elif (EXEC_DIR / str(baseline) / "events.jsonl").is_file() \
                    and (EXEC_DIR / str(baseline)).resolve().parent == EXEC_DIR.resolve():
                baseline_id = baseline
            else:
                raise ValueError("The selected execution to compare with no longer exists.")
            exec_id = f"{datetime.now():%Y%m%d-%H%M%S}_{slugify(tc_name, 40)}"
            n = 2
            while (EXEC_DIR / exec_id).exists():          # two launches within the same second
                exec_id = f"{datetime.now():%Y%m%d-%H%M%S}_{slugify(tc_name, 40)}_{n}"
                n += 1
            d = EXEC_DIR / exec_id
            d.mkdir(parents=True)
            meta = new_meta(exec_id, tc_name, url, baseline_id)
            write_json(d / "meta.json", meta)
            rec = Recorder(d, meta, script=script)
            self.active = rec
            rec.start()
            return rec.live()

    def stop(self, exec_id):
        rec = self.active
        if rec and rec.meta["id"] == exec_id:
            rec.stop()
            return True
        return False

    def open_folder(self, exec_id):
        d = (EXEC_DIR / exec_id).resolve()
        if d.parent != EXEC_DIR.resolve() or not d.is_dir():
            return False
        if sys.platform.startswith("win"):
            os.startfile(str(d))  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(d)])
        else:
            subprocess.Popen(["xdg-open", str(d)])
        return True


def make_handler(app: App):
    class Handler(BaseHTTPRequestHandler):
        server_version = "CaptureAssist/1.0"

        def log_message(self, *args):
            pass

        # ---------------- helpers
        def _json(self, data, status=200):
            body = json.dumps(data).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def _file(self, path: Path, download=False):
            if not path.is_file():
                return self._json({"error": "Not found"}, 404)
            ctype = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
            if ctype.startswith("text/") or ctype in ("application/javascript",):
                ctype += "; charset=utf-8"
            size = path.stat().st_size
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(size))
            self.send_header("Cache-Control", "no-store")
            if download:
                self.send_header("Content-Disposition", f"attachment; filename*=UTF-8''{quote(path.name)}")
            self.end_headers()
            with open(path, "rb") as fh:
                while chunk := fh.read(256 * 1024):
                    self.wfile.write(chunk)

        def _body(self):
            n = int(self.headers.get("Content-Length") or 0)
            if not n:
                return {}
            try:
                return json.loads(self.rfile.read(n).decode("utf-8"))
            except Exception:
                return {}

        @staticmethod
        def _inside(root: Path, rel: str):
            p = (root / unquote(rel)).resolve()
            root = root.resolve()
            return p if p == root or root in p.parents else None

        # ---------------- routes
        def do_GET(self):
            path = urlparse(self.path).path
            query = urlparse(self.path).query
            try:
                if path in ("/", "/index.html"):
                    return self._file(WEB_DIR / "index.html")
                if path in ("/help", "/help.html"):
                    return self._file(WEB_DIR / "help.html")
                if path == "/demo":
                    self.send_response(302)
                    self.send_header("Location", "/demo/")
                    return self.end_headers()
                if path.startswith("/demo/"):
                    rel = path[len("/demo/"):] or "index.html"
                    p = self._inside(WEB_DIR / "demo", rel)
                    return self._file(p) if p else self._json({"error": "Not found"}, 404)
                if path == "/api/executions":
                    return self._json(app.list())
                if path.startswith("/api/executions/"):
                    m = app.get(unquote(path.split("/")[3]))
                    return self._json(m) if m else self._json({"error": "Not found"}, 404)
                if path.startswith("/files/"):
                    parts = path.split("/", 3)
                    if len(parts) == 4:
                        d = self._inside(EXEC_DIR, parts[2])
                        p = self._inside(d, parts[3]) if d and d.parent == EXEC_DIR.resolve() else None
                        if p:
                            return self._file(p, download="view" not in query)
                    return self._json({"error": "Not found"}, 404)
                return self._json({"error": "Not found"}, 404)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def do_POST(self):
            path = urlparse(self.path).path
            try:
                if path == "/api/executions":
                    b = self._body()
                    try:
                        return self._json(app.start(b.get("tc_name"), b.get("url"), baseline=b.get("baseline", "auto")), 201)
                    except (ValueError, RuntimeError) as e:
                        return self._json({"error": str(e)}, 400)
                parts = path.strip("/").split("/")
                if len(parts) == 4 and parts[:2] == ["api", "executions"]:
                    exec_id = unquote(parts[2])
                    if parts[3] == "stop":
                        return self._json({"ok": app.stop(exec_id)})
                    if parts[3] == "open-folder":
                        return self._json({"ok": app.open_folder(exec_id)})
                return self._json({"error": "Not found"}, 404)
            except (BrokenPipeError, ConnectionResetError):
                pass

    return Handler


def create_server(app: App, port: int):
    return ThreadingHTTPServer(("127.0.0.1", port), make_handler(app))
