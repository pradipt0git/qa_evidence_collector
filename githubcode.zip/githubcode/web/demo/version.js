/* Demo Portal "release 2" - simulates application changes so Capture Assist's
 * change detection can be tried. Open the demo with ?v=2 (e.g. /demo/?v=2);
 * the choice is remembered for the rest of the browser session. */
(function () {
  var q = new URLSearchParams(location.search).get('v');
  if (q) sessionStorage.setItem('demoVersion', q);
  if ((sessionStorage.getItem('demoVersion') || '1') !== '2') return;

  function $(id) { return document.getElementById(id); }
  document.addEventListener('DOMContentLoaded', function () {
    var logo = document.querySelector('header .logo span');
    if (logo) logo.textContent = logo.textContent + '  (release 2)';

    // --- login page
    if ($('loginBtn')) $('loginBtn').textContent = 'Sign in';                        // button text changed
    if ($('forgotLink')) $('forgotLink').parentNode.remove();                         // link removed

    // --- registration form
    var lbl = document.querySelector('label[for=fullName]');
    if (lbl) lbl.textContent = 'Customer name';                                      // label changed
    if ($('phone')) $('phone').parentNode.remove();                                   // field removed
    if ($('email')) {                                                                 // field added
      var div = document.createElement('div');
      div.innerHTML = '<label for="pan">PAN number</label><input type="text" id="pan" name="pan" placeholder="ABCDE1234F" required>';
      $('email').parentNode.after(div);
    }
    if ($('plan')) {                                                                  // dropdown option added
      var o = document.createElement('option'); o.value = 'enterprise'; o.textContent = 'Enterprise - 999/month';
      $('plan').appendChild(o);
    }
    if ($('next1')) $('next1').style.background = '#d97706';                          // visual change
    if ($('reviewBtn')) $('reviewBtn').textContent = 'Review & confirm';              // button text changed

    // --- success page
    var h1 = document.querySelector('.card h1');
    if (h1 && h1.textContent === 'Registration submitted') h1.textContent = 'Registration received';
  });
})();
