"""Capture Assist - test evidence recorder.

Usage:
    python capture_assist.py               start dashboard (opens in your default browser)
    python capture_assist.py --port 9000   use a specific port
    python capture_assist.py --no-browser  do not open the dashboard automatically
    python capture_assist.py --selftest    record the built-in demo automatically and verify the output
"""
import argparse
import os
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
# Keep Playwright's helper binaries (ffmpeg for video) inside the tool folder so it stays portable.
os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", str(BASE_DIR / "pw-browsers"))

from server import App, create_server  # noqa: E402


def ensure_ffmpeg():
    """Playwright needs its small ffmpeg build (~2 MB) to write the screen recording."""
    # Always ask Playwright: it is a ~0.5 s silent no-op when the right build (this OS and this
    # Playwright version) is present, and downloads it otherwise (e.g. folder copied from another PC).
    exe = {"win32": "ffmpeg-win64.exe", "darwin": "ffmpeg-mac"}.get(sys.platform, "ffmpeg-linux")
    if not any(Path(os.environ["PLAYWRIGHT_BROWSERS_PATH"]).glob(f"ffmpeg-*/{exe}")):
        print("First run: downloading the video encoder (ffmpeg, ~2 MB)...")
    r = subprocess.run([sys.executable, "-m", "playwright", "install", "ffmpeg"])
    if r.returncode != 0:
        print("WARNING: could not install ffmpeg - executions will be recorded without video.")


def free_port(start):
    for port in range(start, start + 50):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise SystemExit("No free port found.")


def main():
    ap = argparse.ArgumentParser(description="Capture Assist - test evidence recorder")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()

    ensure_ffmpeg()
    port = free_port(args.port)
    app = App()
    httpd = create_server(app, port)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{port}/"

    if args.selftest:
        from selftest import run_selftest
        ok = run_selftest(app, url)
        httpd.shutdown()
        sys.exit(0 if ok else 1)

    print("=" * 60)
    print("  Capture Assist is running")
    print(f"  Dashboard : {url}")
    print(f"  Help      : {url}help")
    print(f"  Demo site : {url}demo/")
    print("  Keep this window open. Press Ctrl+C to quit.")
    print("=" * 60)
    if not args.no_browser:
        webbrowser.open(url)
    try:
        while True:              # sleep loop so Ctrl+C works on Windows consoles
            time.sleep(1)
    except KeyboardInterrupt:
        rec = app.active
        if rec and rec.is_alive():
            print("Stopping active execution and generating document...")
            rec.stop()
            rec.join(timeout=60)
        print("Bye.")


if __name__ == "__main__":
    main()
