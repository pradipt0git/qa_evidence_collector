"""Capture Assist self-test: records the built-in demo site automatically and verifies the evidence."""
import json
import re
import zipfile

from server import EXEC_DIR

PASSWORD = "Secret@123"


def _demo_script(page):
    """Drives the demo like a tester. Clicks with delay=0 exercise the click gate,
    clicks with delay=120 behave like a human (mouse down/up gap)."""
    page.wait_for_load_state("load")
    page.wait_for_timeout(1200)
    page.click("#username")
    page.fill("#username", "tester01")
    page.fill("#password", PASSWORD)
    page.click("#remember", delay=120)
    page.click("#loginBtn", delay=120)
    page.wait_for_url("**/form.html")
    page.wait_for_timeout(1200)
    page.fill("#fullName", "John Doe")
    page.fill("#email", "john.doe@example.com")
    page.fill("#dob", "1990-05-12")
    page.click("#genderM")
    page.click("#tab-address")                      # in-page section change, no delay: gate path
    page.fill("#street", "12 MG Road, Indiranagar")
    page.fill("#city", "Bengaluru")
    page.select_option("#country", "IN")
    page.click("#next2", delay=120)
    page.select_option("#plan", "premium")
    page.click("#newsletter")
    page.click("#terms")
    page.fill("#comments", "Created by self-test")
    page.click("#reviewBtn")
    page.wait_for_timeout(500)
    page.click("#submitBtn", delay=120)
    page.wait_for_url("**/success.html*")
    page.wait_for_timeout(1500)
    page.close()                                    # same as the tester closing the window


def _run(app, url, baseline):
    meta = app.start("SELFTEST - Demo Login and Registration", url, script=_demo_script, baseline=baseline)
    app.active.join(timeout=300)
    d = EXEC_DIR / meta["id"]
    return d, json.loads((d / "meta.json").read_text(encoding="utf-8"))


def run_selftest(app, base_url):
    results = []

    def check(name, ok, detail=""):
        results.append(bool(ok))
        print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"  ({detail})" if detail else ""))

    # ------------------------------------------------------------ run 1: evidence capture
    print("Self-test 1/2: recording the demo site automatically...")
    d, meta = _run(app, base_url + "demo/", baseline="none")
    events = [json.loads(l) for l in (d / "events.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
    snaps = [e for e in events if e["kind"] == "snapshot"]
    inputs = [e for e in events if e["kind"] == "input"]

    check("execution completed", meta.get("status") == "completed", meta.get("status") + " " + str(meta.get("error") or ""))
    doc = d / (meta.get("doc") or "missing.docx")
    check("evidence document created", doc.is_file(), doc.name)
    if doc.is_file():
        from docx import Document
        title = Document(str(doc)).paragraphs[0].text
        check("document title is the TC name", title == meta["tc_name"], title)
        xml = zipfile.ZipFile(doc).read("word/document.xml").decode("utf-8")
        check("document contains entered data", "John Doe" in xml and "Bengaluru" in xml)
        check("password not in document", PASSWORD not in xml)
    check("at least 10 screenshots", len(snaps) >= 10, f"{len(snaps)} screenshots")
    check("every screenshot has image + DOM",
          all(s.get("screenshot") and (d / s["screenshot"]).is_file() and s.get("dom") and (d / s["dom"]).is_file() for s in snaps))
    leaked = [p.name for p in d.rglob("*") if p.is_file() and p.suffix in (".html", ".jsonl", ".json")
              and PASSWORD in p.read_text(encoding="utf-8", errors="ignore")]
    check("password masked everywhere", not leaked, ", ".join(leaked))
    overlay = [p.name for p in (d / "dom").glob("*.html") if "ca-overlay" in p.read_text(encoding="utf-8", errors="ignore")]
    check("click/focus overlay kept out of DOM snapshots", not overlay, ", ".join(overlay))
    tab = next((s for s in snaps if (s.get("element") or {}).get("id") == "tab-address"), None)
    check("screenshot taken on in-page tab click", tab is not None)
    if tab:
        dom = (d / tab["dom"]).read_text(encoding="utf-8")
        before = re.search(r'<section class="panel active" id="panel-personal"', dom) is not None
        check("DOM captured BEFORE the tab switched", before)
        check("DOM contains typed values", 'value="John Doe"' in dom)
    by_field = {(e.get("element") or {}).get("id"): e.get("value") for e in inputs}
    check("dropdown selection recorded", (by_field.get("country") or "").startswith("India"), by_field.get("country"))
    check("checkbox recorded", by_field.get("newsletter") == "Checked", by_field.get("newsletter"))
    check("password input recorded masked", by_field.get("password") == "********", by_field.get("password"))
    vids = [d / v for v in meta.get("videos") or []]
    check("video recorded", bool(vids) and all(v.is_file() and v.stat().st_size > 10_000 for v in vids),
          ", ".join(f"{v.name} {v.stat().st_size // 1024} KB" for v in vids if v.is_file()))
    check("no comparison on a first execution", not meta.get("comparison"))

    # ------------------------------------------------------------ run 2: re-execution on a changed app
    print("Self-test 2/2: re-executing the same test case on demo 'release 2' (changed application)...")
    d2, meta2 = _run(app, base_url + "demo/?v=2", baseline="auto")
    check("re-execution completed", meta2.get("status") == "completed", meta2.get("status") + " " + str(meta2.get("error") or ""))
    check("previous run picked as baseline", meta2.get("baseline_id") == meta["id"], meta2.get("baseline_id"))
    cmp_doc = d2 / (meta2.get("comparison") or "missing.docx")
    check("comparison document created", cmp_doc.is_file(), cmp_doc.name + " " + str(meta2.get("comparison_error") or ""))
    check("differences detected", (meta2.get("changes") or 0) > 0, f"{meta2.get('changes')} differences")
    if cmp_doc.is_file():
        xml = zipfile.ZipFile(cmp_doc).read("word/document.xml").decode("utf-8")
        for what, needle in [("button text change (Login -> Sign in)", "Sign in"),
                             ("label change (Full name -> Customer name)", "Customer name"),
                             ("added field (PAN number)", "PAN number"),
                             ("removed field (Phone)", "Phone"),
                             ("added dropdown option (Enterprise)", "Enterprise"),
                             ("removed link (Forgot password?)", "Forgot password?")]:
            check(f"detected {what}", needle in xml)
    marked = list((d2 / "comparison").glob("*_changes.jpg"))
    check("changed regions marked on screenshots", bool(marked), f"{len(marked)} images")

    ok = all(results)
    print(f"\nSelf-test {'PASSED' if ok else 'FAILED'}\n  run 1 -> {d}\n  run 2 -> {d2}")
    return ok
