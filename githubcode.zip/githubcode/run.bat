@echo off
setlocal
title Capture Assist
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [Capture Assist] First run - creating private Python environment...
    call :findpy
    if errorlevel 1 goto :nopy
    %PY% -m venv --clear .venv
    if errorlevel 1 goto :fail
)

if not exist ".venv\.installed" (
    echo [Capture Assist] Installing playwright and python-docx...
    if exist "wheels\" (
        ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check --no-index --find-links wheels -r requirements.txt
    ) else (
        ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
    )
    if errorlevel 1 goto :fail
    echo ok> ".venv\.installed"
)

".venv\Scripts\python.exe" capture_assist.py %*
if errorlevel 1 pause
exit /b 0

:findpy
py -3 --version >nul 2>&1
if not errorlevel 1 (set "PY=py -3" & exit /b 0)
python --version >nul 2>&1
if not errorlevel 1 (set "PY=python" & exit /b 0)
exit /b 1

:nopy
echo.
echo Python 3.9+ was not found. Install it from https://www.python.org/downloads/
echo and tick "Add Python to PATH" during installation, then run this file again.
pause
exit /b 1

:fail
echo.
echo Setup failed. Check your internet connection (or provide a "wheels" folder) and try again.
pause
exit /b 1
