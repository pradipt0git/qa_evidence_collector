"""Capture Assist - compares a re-execution of a test case with an earlier execution.

Produces <TC>_Comparison.docx (baseline vs current) covering:
  * step flow   - steps aligned even if the tester clicked a little differently
  * page changes - elements added / removed / modified (labels, buttons, fields, options, locators)
  * visuals     - side-by-side screenshots with changed regions boxed in red
  * test data   - values entered differently (informational, not an application change)
"""
import base64
import json
import re
from difflib import SequenceMatcher
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor

from report import ACCENT, _cell_text, _grid_table, _kv_table, _shade

MATCH_THRESHOLD = 0.5      # minimum similarity to treat two steps as "the same step"
VISUAL_THRESHOLD = 0.5     # % of screen that must change to report a visual difference
HALF_WIDTH = Inches(3.55)

STATUS_STYLE = {           # label -> (cell colour, text colour)
    "Same": ("E7F6EC", "166534"),
    "Changed": ("FFF4DB", "92400E"),
    "Visual change": ("F3E8FF", "6B21A8"),
    "Added": ("E0ECFF", "1E40AF"),
    "Removed": ("FDE2E2", "991B1B"),
}


# --------------------------------------------------------------------------- helpers
def _norm(s):
    return re.sub(r"\s+", " ", (s or "")).strip()


def _ratio(a, b):
    a, b = _norm(a).lower(), _norm(b).lower()
    if a == b:
        return 1.0
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b).ratio()


def page_key(url):
    """Pages are identified by their path. Host/port (environment) and the query string
    (record IDs, search terms, generated reference numbers) are ignored, so they never
    count as an application change."""
    if not url:
        return ""
    return urlparse(url).path or "/"


def load_events(exec_dir: Path):
    events = []
    f = exec_dir / "events.jsonl"
    if f.exists():
        for line in f.read_text(encoding="utf-8").splitlines():
            try:
                events.append(json.loads(line))
            except Exception:
                pass
    events.sort(key=lambda e: (e.get("ts") or 0, e.get("step") or 0))
    return events


def steps_with_inputs(events):
    """Snapshot steps, each carrying the inputs entered just before it."""
    steps, pending = [], []
    for ev in events:
        if ev.get("kind") == "input":
            pending.append(ev)
        elif ev.get("kind") == "snapshot":
            s = dict(ev)
            s["inputs"] = pending
            pending = []
            steps.append(s)
    return steps


def step_label(s):
    from recorder import describe_step
    return f"{s['step']}. {describe_step(s)}"


# --------------------------------------------------------------------------- page inventory
VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "source", "track", "wbr"}
SKIP = {"script", "style", "noscript", "template", "svg", "ca-overlay"}
ROLES = {"button", "link", "tab", "menuitem", "checkbox", "radio", "switch", "option", "combobox", "textbox"}
FIELDS = ["tag", "type", "label", "text", "placeholder", "aria-label", "title", "href", "role", "name", "id",
          "value", "options", "required", "disabled", "readonly"]
FIELD_NAMES = {"tag": "Element type", "type": "Input type", "label": "Label", "text": "Text", "placeholder": "Placeholder",
               "aria-label": "Accessible name", "title": "Tooltip", "href": "Link target", "role": "Role",
               "name": "Name attribute", "id": "ID", "value": "Option value", "options": "Dropdown options",
               "required": "Mandatory", "disabled": "Disabled", "readonly": "Read-only"}
AUTO_ID = re.compile(r"\d{3,}|^:|^(mat-|ember|ext-|ui-id|react|radix|headlessui|mui|rc_|uid|id-)|[0-9a-f]{8,}", re.I)


class _Inventory(HTMLParser):
    """Collects the interactive / structural elements of a saved DOM snapshot."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.items, self.open, self.labels = [], [], []
        self.skip = 0
        self.select = None
        self.option = None
        self.title = []
        self.in_title = False

    def handle_starttag(self, tag, attrs):
        if self.skip:
            if tag in SKIP:
                self.skip += 1
            return
        if tag in SKIP:
            self.skip = 1
            return
        a = {k: (v or "") for k, v in attrs}
        if tag == "title":
            self.in_title = True
        if tag == "label":
            self.labels.append({"for": a.get("for", ""), "text": [], "controls": [], "depth": len(self.open)})
        if tag == "option" and self.select is not None:
            self.option = []
        typ = a.get("type", "").lower()
        tracked = tag in ("input", "select", "textarea", "button", "a", "h1", "h2", "h3", "h4", "h5", "h6") \
            or a.get("role", "").lower() in ROLES
        if (tag == "input" and typ == "hidden") or (tag == "a" and "href" not in a and not a.get("role")):
            tracked = False
        if tracked:
            href = a.get("href", "")
            if href and not href.startswith(("javascript:", "#", "mailto:", "tel:")):
                href = page_key(href) if "://" in href or href.startswith("/") else href.split("?")[0]
            item = {
                "tag": tag, "type": typ, "id": a.get("id", ""), "name": a.get("name", ""), "role": a.get("role", ""),
                "placeholder": a.get("placeholder", ""), "aria-label": a.get("aria-label", ""), "title": a.get("title", ""),
                "href": href, "required": "Yes" if "required" in a or a.get("aria-required") == "true" else "",
                "disabled": "Yes" if "disabled" in a or a.get("aria-disabled") == "true" else "",
                "readonly": "Yes" if "readonly" in a else "",
                "value": a.get("value", "") if typ in ("radio", "checkbox", "submit", "button", "reset") else "",
                "_text": [], "label": "", "options": "",
            }
            if tag == "input" and typ in ("submit", "button", "reset"):
                item["_text"].append(a.get("value", ""))
            if self.labels and tag in ("input", "select", "textarea"):
                self.labels[-1]["controls"].append(item)
            self.items.append(item)
            if tag == "select":
                self.select = item
                item["_opts"] = []
            if tag not in VOID:
                self.open.append((tag, item))

    def handle_endtag(self, tag):
        if self.skip:
            if tag in SKIP:
                self.skip -= 1
            return
        if tag == "title":
            self.in_title = False
        if tag == "option" and self.select is not None and self.option is not None:
            self.select["_opts"].append(_norm(" ".join(self.option)))
            self.option = None
        if tag == "select":
            self.select = None
        if tag == "label" and self.labels:
            lab = self.labels.pop()
            text = _norm(" ".join(lab["text"]))
            for c in lab["controls"]:
                c["label"] = c["label"] or text
            if lab["for"]:
                for it in self.items:
                    if it["id"] == lab["for"] and not it["label"]:
                        it["label"] = text
                self._pending_for = getattr(self, "_pending_for", [])
                self._pending_for.append((lab["for"], text))
        for i in range(len(self.open) - 1, -1, -1):
            if self.open[i][0] == tag:
                del self.open[i:]
                break

    def handle_data(self, data):
        if self.skip:
            return
        if self.in_title:
            self.title.append(data)
        for lab in self.labels:
            lab["text"].append(data)
        if self.option is not None:
            self.option.append(data)
        for tag, item in self.open:
            if tag not in ("select", "textarea"):
                item["_text"].append(data)

    def result(self):
        late = dict(getattr(self, "_pending_for", []))   # <label for> that appears after its control
        out = []
        for it in self.items:
            if not it["label"] and it["id"] in late:
                it["label"] = late[it["id"]]
            it["text"] = _norm(" ".join(it.pop("_text")))[:100]
            if "_opts" in it:
                it["options"] = " | ".join(o for o in it.pop("_opts") if o)[:400]
            it["label"] = it["label"][:100]
            out.append(it)
        return _norm(" ".join(self.title)), out


_inv_cache = {}


def inventory(path: Path):
    if path in _inv_cache:
        return _inv_cache[path]
    title, items = "", []
    try:
        p = _Inventory()
        p.feed(path.read_text(encoding="utf-8", errors="ignore"))
        p.close()
        title, items = p.result()
    except Exception:
        pass
    _inv_cache[path] = (title, items)
    return title, items


def element_name(it):
    return it.get("label") or it.get("text") or it.get("aria-label") or it.get("placeholder") \
        or it.get("title") or it.get("name") or it.get("id") or it.get("tag")


def element_key(it):
    if it["id"] and not AUTO_ID.search(it["id"]):
        return "id:" + it["id"]
    if it["name"] and it["tag"] in ("input", "select", "textarea", "button"):
        return f"name:{it['tag']}:{it['type']}:{it['name']}:{it['value']}"
    return f"{it['tag']}:{it['type']}:{_norm(element_name(it)).lower()}"


def diff_inventories(old_items, new_items):
    """Element-level differences between two pages."""
    changes = []
    ka, kb = [element_key(i) for i in old_items], [element_key(i) for i in new_items]
    sm = SequenceMatcher(None, ka, kb, autojunk=False)
    # first pass: exact key matches anywhere (handles re-ordering), then pair leftovers by position
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        olds, news = old_items[i1:i2], new_items[j1:j2]
        if op == "equal":
            pairs, rem, add = list(zip(olds, news)), [], []
        elif op == "replace":
            pairs, rem, add = [], [], []
            used = set()
            for o in olds:
                match = next((j for j, n in enumerate(news) if j not in used and n["tag"] == o["tag"]
                              and (n["type"] == o["type"] or o["tag"] != "input")), None)
                if match is None:
                    rem.append(o)
                else:
                    used.add(match)
                    pairs.append((o, news[match]))
            add = [n for j, n in enumerate(news) if j not in used]
        elif op == "delete":
            pairs, rem, add = [], olds, []
        else:
            pairs, rem, add = [], [], news
        for o, n in pairs:
            for f in FIELDS:
                if (o.get(f) or "") != (n.get(f) or ""):
                    changes.append({"kind": "Modified", "element": f"{element_name(n)} ({n['tag']})",
                                    "attribute": FIELD_NAMES[f], "old": o.get(f) or "(none)", "new": n.get(f) or "(none)"})
        for o in rem:
            changes.append({"kind": "Removed", "element": f"{element_name(o)} ({o['tag']})", "attribute": "",
                            "old": _describe_item(o), "new": ""})
        for n in add:
            changes.append({"kind": "Added", "element": f"{element_name(n)} ({n['tag']})", "attribute": "",
                            "old": "", "new": _describe_item(n)})
    return changes


def _describe_item(it):
    bits = [f"<{it['tag']}{(' type=' + it['type']) if it['type'] else ''}>"]
    for f in ("id", "name", "label", "text", "placeholder"):
        if it.get(f):
            bits.append(f"{f}: {it[f]}")
    return ", ".join(bits)[:220]


# --------------------------------------------------------------------------- step alignment
def step_similarity(a, b):
    if a.get("action") != b.get("action"):
        return 0.0
    same_page = page_key(a.get("url")) == page_key(b.get("url"))
    s = 0.35 if same_page else 0.0
    if a.get("action") == "load":
        return s + 0.65 * _ratio(a.get("title"), b.get("title"))
    ea, eb = a.get("element") or {}, b.get("element") or {}
    s += 0.25 * _ratio(ea.get("name"), eb.get("name"))
    s += 0.20 if ea.get("id") and ea.get("id") == eb.get("id") else 0.0
    s += 0.10 if ea.get("css") and ea.get("css") == eb.get("css") else 0.0
    s += 0.10 if ea.get("tag") == eb.get("tag") and ea.get("type") == eb.get("type") else 0.0
    return s


def align_steps(old, new):
    """Needleman-Wunsch style alignment maximising total step similarity."""
    n, m = len(old), len(new)
    sim = [[step_similarity(o, w) for w in new] for o in old]
    score = [[0.0] * (m + 1) for _ in range(n + 1)]
    for i in range(n - 1, -1, -1):
        for j in range(m - 1, -1, -1):
            best = max(score[i + 1][j], score[i][j + 1])
            if sim[i][j] >= MATCH_THRESHOLD:
                best = max(best, sim[i][j] + score[i + 1][j + 1])
            score[i][j] = best
    i = j = 0
    out = []
    while i < n and j < m:
        if sim[i][j] >= MATCH_THRESHOLD and abs(score[i][j] - (sim[i][j] + score[i + 1][j + 1])) < 1e-9:
            out.append((old[i], new[j]))
            i, j = i + 1, j + 1
        elif score[i + 1][j] >= score[i][j + 1]:
            out.append((old[i], None))
            i += 1
        else:
            out.append((None, new[j]))
            j += 1
    out += [(o, None) for o in old[i:]] + [(None, w) for w in new[j:]]
    return out


STEP_FIELDS = [("name", "Element name"), ("actionType", "Element kind"), ("tag", "Tag"), ("type", "Input type"),
               ("id", "Element ID"), ("nameAttr", "Name attribute"), ("role", "Role"), ("href", "Link target"),
               ("css", "CSS selector"), ("xpath", "XPath")]


def step_differences(a, b):
    diffs = []
    if _norm(a.get("title")) != _norm(b.get("title")):
        diffs.append(("Page title", a.get("title") or "", b.get("title") or ""))
    if page_key(a.get("url")) != page_key(b.get("url")):
        diffs.append(("Page URL", a.get("url") or "", b.get("url") or ""))
    ea, eb = a.get("element") or {}, b.get("element") or {}
    for f, label in STEP_FIELDS:
        va, vb = ea.get(f) or "", eb.get(f) or ""
        if f == "href":
            va, vb = page_key(va) if "://" in va else va, page_key(vb) if "://" in vb else vb
        if _norm(str(va)) != _norm(str(vb)):
            diffs.append((label, ea.get(f) or "", eb.get(f) or ""))
    return diffs


def data_differences(a, b, step_ref):
    def field_map(step):
        out = {}
        for ev in step.get("inputs") or []:
            el = ev.get("element") or {}
            k = el.get("id") or el.get("nameAttr") or el.get("name")
            out[k] = (el.get("name") or k, ev.get("value", ""))
        return out
    fa, fb = field_map(a), field_map(b)
    rows = []
    for k in list(dict.fromkeys(list(fa) + list(fb))):
        va, vb = fa.get(k, (None, "(not entered)")), fb.get(k, (None, "(not entered)"))
        if va[1] != vb[1]:
            rows.append((vb[0] or va[0] or k, va[1], vb[1], step_ref))
    return rows


# --------------------------------------------------------------------------- visual diff
VISUAL_JS = r"""
async ([a, b]) => {
  const load = (s) => new Promise((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = () => rej(new Error('image')); i.src = s; });
  const [A, B] = await Promise.all([load(a), load(b)]);
  const W = 320, H = Math.max(8, Math.round(B.naturalHeight * W / B.naturalWidth));
  const px = (img) => { const c = document.createElement('canvas'); c.width = W; c.height = H;
    const x = c.getContext('2d', { willReadFrequently: true }); x.drawImage(img, 0, 0, W, H); return x.getImageData(0, 0, W, H).data; };
  const da = px(A), db = px(B);
  const S = 8, cols = Math.ceil(W / S), rows = Math.ceil(H / S), grid = new Uint8Array(cols * rows);
  let changed = 0;
  for (let by = 0; by < rows; by++) for (let bx = 0; bx < cols; bx++) {
    let d = 0, n = 0;
    for (let y = by * S; y < Math.min(H, by * S + S); y++) for (let x = bx * S; x < Math.min(W, bx * S + S); x++) {
      const i = (y * W + x) * 4;
      if (Math.max(Math.abs(da[i] - db[i]), Math.abs(da[i + 1] - db[i + 1]), Math.abs(da[i + 2] - db[i + 2])) > 40) d++;
      n++;
    }
    if (d / n > 0.12) { grid[by * cols + bx] = 1; changed++; }
  }
  const seen = new Uint8Array(grid.length), boxes = [];
  for (let k = 0; k < grid.length; k++) {
    if (!grid[k] || seen[k]) continue;
    let x0 = 1e9, y0 = 1e9, x1 = -1, y1 = -1; const st = [k]; seen[k] = 1;
    while (st.length) {
      const c = st.pop(), cx = c % cols, cy = (c / cols) | 0;
      x0 = Math.min(x0, cx); y0 = Math.min(y0, cy); x1 = Math.max(x1, cx); y1 = Math.max(y1, cy);
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        const nx = cx + dx, ny = cy + dy;
        if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue;
        const nk = ny * cols + nx;
        if (grid[nk] && !seen[nk]) { seen[nk] = 1; st.push(nk); }
      }
    }
    boxes.push([x0, y0, x1, y1]);
  }
  let img = null;
  if (boxes.length) {
    const out = document.createElement('canvas'); out.width = B.naturalWidth; out.height = B.naturalHeight;
    const o = out.getContext('2d'); o.drawImage(B, 0, 0);
    const f = B.naturalWidth / W, pad = 3 * f;
    o.lineWidth = Math.max(3, Math.round(f)); o.strokeStyle = 'rgba(220,38,38,0.95)'; o.fillStyle = 'rgba(220,38,38,0.10)';
    for (const [x0, y0, x1, y1] of boxes) {
      const X = x0 * S * f - pad, Y = y0 * S * f - pad, Wd = (x1 - x0 + 1) * S * f + 2 * pad, Ht = (y1 - y0 + 1) * S * f + 2 * pad;
      o.fillRect(X, Y, Wd, Ht); o.strokeRect(X, Y, Wd, Ht);
    }
    img = out.toDataURL('image/jpeg', 0.82);
  }
  const ra = A.naturalWidth / A.naturalHeight, rb = B.naturalWidth / B.naturalHeight;
  return { pct: changed * 100 / (cols * rows), regions: boxes.length, sizeDiffers: Math.abs(ra - rb) > 0.02, img };
}
"""


def _data_url(path: Path):
    return "data:image/jpeg;base64," + base64.b64encode(path.read_bytes()).decode()


def visual_diffs(jobs):
    """jobs: list of (old_jpg, new_jpg, out_jpg). Returns list of result dicts (or None)."""
    results = [None] * len(jobs)
    if not jobs:
        return results
    try:
        from playwright.sync_api import sync_playwright
        from recorder import CHANNELS
        with sync_playwright() as p:
            browser = None
            for channel, _ in CHANNELS:
                try:
                    browser = p.chromium.launch(headless=True, **({"channel": channel} if channel else {}))
                    break
                except Exception:
                    continue
            if browser is None:
                return results
            page = browser.new_page()
            for k, (a, b, out) in enumerate(jobs):
                try:
                    r = page.evaluate(VISUAL_JS, [_data_url(a), _data_url(b)])
                    if r.get("img"):
                        out.parent.mkdir(exist_ok=True)
                        out.write_bytes(base64.b64decode(r["img"].split(",", 1)[1]))
                        r["img"] = out
                    results[k] = r
                except Exception:
                    pass
            browser.close()
    except Exception:
        pass
    return results


# --------------------------------------------------------------------------- main entry
def build_comparison(new_dir: Path, new_meta: dict, new_events: list, old_dir: Path):
    old_meta = json.loads((old_dir / "meta.json").read_text(encoding="utf-8"))
    old_steps = steps_with_inputs(load_events(old_dir))
    new_steps = steps_with_inputs(new_events)
    aligned = align_steps(old_steps, new_steps)

    rows, page_changes, data_rows, details, jobs = [], {}, [], [], []
    seen_changes = set()
    for o, n in aligned:
        if o and n:
            diffs = step_differences(o, n)
            if o.get("dom") and n.get("dom") and (old_dir / o["dom"]).exists() and (new_dir / n["dom"]).exists():
                _, inv_o = inventory(old_dir / o["dom"])
                _, inv_n = inventory(new_dir / n["dom"])
                pk = page_key(n.get("url"))
                for c in diff_inventories(inv_o, inv_n):
                    sig = (pk, c["kind"], c["element"], c["attribute"], c["old"], c["new"])
                    if sig not in seen_changes:
                        seen_changes.add(sig)
                        c["step"] = n["step"]
                        page_changes.setdefault(pk, []).append(c)
            data_rows += data_differences(o, n, f"{o['step']} / {n['step']}")
            entry = {"old": o, "new": n, "diffs": diffs, "status": "Changed" if diffs else "Same", "visual": None}
            if o.get("screenshot") and n.get("screenshot") and (old_dir / o["screenshot"]).exists() \
                    and (new_dir / n["screenshot"]).exists():
                jobs.append((old_dir / o["screenshot"], new_dir / n["screenshot"],
                             new_dir / "comparison" / f"step_{n['step']:03d}_changes.jpg", entry))
        elif o:
            entry = {"old": o, "new": None, "diffs": [], "status": "Removed", "visual": None}
        else:
            entry = {"old": None, "new": n, "diffs": [], "status": "Added", "visual": None}
        details.append(entry)

    for (_, _, _, entry), res in zip(jobs, visual_diffs([j[:3] for j in jobs])):
        entry["visual"] = res
        if res and res["pct"] >= VISUAL_THRESHOLD and entry["status"] == "Same":
            entry["status"] = "Visual change"

    counts = {s: sum(1 for d in details if d["status"] == s) for s in STATUS_STYLE}
    element_changes = sum(len(v) for v in page_changes.values())
    counts["Element changes"] = element_changes
    counts["Test data differences"] = len(data_rows)
    total = counts["Changed"] + counts["Added"] + counts["Removed"] + counts["Visual change"] + element_changes

    name = _write_doc(new_dir, old_dir, new_meta, old_meta, details, page_changes, data_rows, counts, total)
    summary = {"baseline_id": old_meta["id"], "total": total, "counts": counts, "file": name}
    (new_dir / "comparison.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


# --------------------------------------------------------------------------- document
def _status_cell(cell, status, label=None):
    bg, fg = STATUS_STYLE[status]
    _cell_text(cell, label or status, bold=True, color=fg)
    _shade(cell, bg)


def _two_images(doc, left, right, left_cap, right_cap):
    t = doc.add_table(rows=2, cols=2)
    t.autofit = False
    for j, (img, cap) in enumerate(((left, left_cap), (right, right_cap))):
        t.columns[j].width = HALF_WIDTH
        c = t.rows[0].cells[j]
        c.width = HALF_WIDTH
        _cell_text(c, cap, bold=True, color=ACCENT)
        c2 = t.rows[1].cells[j]
        c2.width = HALF_WIDTH
        p = c2.paragraphs[0]
        if img and Path(img).exists():
            p.add_run().add_picture(str(img), width=HALF_WIDTH - Inches(0.1))
        else:
            p.add_run("(no screenshot)").italic = True


def _write_doc(new_dir, old_dir, new_meta, old_meta, details, page_changes, data_rows, counts, total):
    from recorder import describe_step, slugify
    doc = Document()
    sec = doc.sections[0]
    sec.left_margin = sec.right_margin = Inches(0.6)
    sec.top_margin = sec.bottom_margin = Inches(0.6)
    doc.styles["Normal"].font.name = "Calibri"
    doc.styles["Normal"].font.size = Pt(10)
    fp = sec.footer.paragraphs[0]
    fp.text = f"Capture Assist  |  Change comparison  |  {new_meta['tc_name']}"
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for r in fp.runs:
        r.font.size = Pt(8)
        r.font.color.rgb = RGBColor(0x88, 0x88, 0x88)

    doc.add_heading(new_meta["tc_name"], 0)
    sub = doc.add_paragraph()
    run = sub.add_run("Change Comparison: Baseline (old) vs Current (new)")
    run.font.size = Pt(12)
    run.font.color.rgb = RGBColor.from_string(ACCENT)

    res = doc.add_paragraph()
    res.paragraph_format.space_before = Pt(4)
    r = res.add_run(f"{total} difference{'s' if total != 1 else ''} detected" if total else "No application differences detected")
    r.bold = True
    r.font.size = Pt(14)
    r.font.color.rgb = RGBColor.from_string("B45309" if total else "15803D")

    t = _grid_table(doc, ["", "Baseline (old)", "Current (new)"], [
        ("Execution ID", old_meta["id"], new_meta["id"]),
        ("Started", (old_meta.get("started") or "").replace("T", " "), (new_meta.get("started") or "").replace("T", " ")),
        ("Launch URL", old_meta.get("url"), new_meta.get("url")),
        ("Browser", old_meta.get("browser"), new_meta.get("browser")),
        ("Tester", old_meta.get("tester"), new_meta.get("tester")),
        ("Screenshots / steps", str(sum(1 for d in details if d["old"])), str(sum(1 for d in details if d["new"]))),
    ], widths=[Inches(1.7), Inches(2.8), Inches(2.8)])
    for row in t.rows[1:]:
        _shade(row.cells[0], "E8EEF5")

    doc.add_heading("Summary", 1)
    _kv_table(doc, [
        ("Steps unchanged", str(counts["Same"])),
        ("Steps changed", str(counts["Changed"])),
        ("Steps with visual change only", str(counts["Visual change"])),
        ("Steps only in current (added)", str(counts["Added"])),
        ("Steps only in baseline (removed)", str(counts["Removed"])),
        ("Page element changes", str(counts["Element changes"])),
        ("Test data differences (info only)", str(counts["Test data differences"])),
    ], label_width=Inches(2.6))
    note = doc.add_paragraph()
    note.paragraph_format.space_before = Pt(6)
    nr = note.add_run("Steps are matched by action, page and element, so small differences in how the test was "
                      "performed do not hide real changes. Host/port and URL parameters (?...) are ignored when "
                      "comparing pages. Test data differences are listed for information only.")
    nr.italic = True
    nr.font.size = Pt(8.5)

    # ---- step flow
    doc.add_heading("Step flow", 1)
    flow = _grid_table(doc, ["#", "Baseline step", "Current step", "Result"],
                       [(str(i), step_label(d["old"]) if d["old"] else "-", step_label(d["new"]) if d["new"] else "-", "")
                        for i, d in enumerate(details, 1)],
                       widths=[Inches(0.4), Inches(2.9), Inches(2.9), Inches(1.1)])
    for i, d in enumerate(details, 1):
        _status_cell(flow.rows[i].cells[3], d["status"])

    # ---- page element changes
    doc.add_heading("Page element changes", 1)
    if not page_changes:
        doc.add_paragraph("No elements were added, removed or modified on the compared pages.")
    for pk, changes in page_changes.items():
        doc.add_heading(f"Page: {pk or '/'}", 2)
        tbl = _grid_table(doc, ["Change", "Element", "What changed", "Baseline (old)", "Current (new)"],
                          [(c["kind"], c["element"], c["attribute"] or "-", c["old"], c["new"]) for c in changes],
                          widths=[Inches(0.8), Inches(1.6), Inches(1.1), Inches(1.9), Inches(1.9)])
        for i, c in enumerate(changes, 1):
            st = {"Modified": "Changed", "Added": "Added", "Removed": "Removed"}[c["kind"]]
            _status_cell(tbl.rows[i].cells[0], st, c["kind"])

    # ---- step details
    doc.add_heading("Changed steps in detail", 1)
    shown = 0
    for d in details:
        if d["status"] == "Same":
            continue
        shown += 1
        o, n, v = d["old"], d["new"], d["visual"]
        if o and n:
            doc.add_heading(f"Baseline step {o['step']}  ↔  Current step {n['step']}: {describe_step(n)}", 2)
        elif n:
            doc.add_heading(f"Added in current - step {n['step']}: {describe_step(n)}", 2)
        else:
            doc.add_heading(f"Removed (only in baseline) - step {o['step']}: {describe_step(o)}", 2)
        status_p = doc.add_paragraph()
        sr = status_p.add_run(d["status"])
        sr.bold = True
        sr.font.color.rgb = RGBColor.from_string(STATUS_STYLE[d["status"]][1])
        if v:
            extra = f"   Visual change: {v['pct']:.1f}% of the screen, {v['regions']} region(s)"
            if v.get("sizeDiffers"):
                extra += " (screen sizes differ between runs)"
            status_p.add_run(extra).font.size = Pt(9)
        if d["diffs"]:
            _grid_table(doc, ["What changed", "Baseline (old)", "Current (new)"], d["diffs"],
                        widths=[Inches(1.5), Inches(2.9), Inches(2.9)])
            doc.add_paragraph()
        left = (old_dir / o["screenshot"]) if o and o.get("screenshot") else None
        right = (new_dir / n["screenshot"]) if n and n.get("screenshot") else None
        marked = v.get("img") if v else None
        _two_images(doc, left, marked or right, "Baseline (old)",
                    "Current (new) - changed regions in red" if marked else "Current (new)")
    if not shown:
        doc.add_paragraph("All steps match the baseline.")

    # ---- test data
    doc.add_heading("Test data differences (information only)", 1)
    if data_rows:
        _grid_table(doc, ["Field", "Baseline value", "Current value", "Steps (old / new)"], data_rows,
                    widths=[Inches(2.0), Inches(2.2), Inches(2.2), Inches(0.9)])
    else:
        doc.add_paragraph("The same data was entered in both executions.")

    name = f"{slugify(new_meta['tc_name'])}_Comparison.docx"
    doc.save(str(new_dir / name))
    return name
