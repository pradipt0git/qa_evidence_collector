"""Capture Assist - Playwright recording session (one thread per execution)."""
import base64
import getpass
import json
import platform
import re
import threading
import time
import traceback
from datetime import datetime
from pathlib import Path

from playwright.sync_api import sync_playwright

BASE_DIR = Path(__file__).resolve().parent
CAPTURE_JS = BASE_DIR / "capture.js"
CHANNELS = [("msedge", "Microsoft Edge"), ("chrome", "Google Chrome"), (None, "Chromium (bundled)")]


def slugify(text, maxlen=60):
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", text.strip()).strip("._-")
    return (s or "TC")[:maxlen]


BROWSER_TOOLBAR_PX = 88    # tab strip + address bar of a maximized Edge/Chrome window (logical px)


def screen_size():
    """Video size matching the page area of a maximized browser window: the desktop work
    area (screen minus taskbar) minus the browser toolbars. Logical pixels, so it lines up
    with the CSS viewport. A close match avoids grey padding bands in the recording."""
    try:
        import ctypes
        from ctypes import wintypes
        rect = wintypes.RECT()
        if ctypes.windll.user32.SystemParametersInfoW(48, 0, ctypes.byref(rect), 0):   # SPI_GETWORKAREA
            w, h = rect.right - rect.left, rect.bottom - rect.top - BROWSER_TOOLBAR_PX
        else:
            w, h = ctypes.windll.user32.GetSystemMetrics(0), ctypes.windll.user32.GetSystemMetrics(1) - 40 - BROWSER_TOOLBAR_PX
        if w > 0 and h > 0:
            return w - w % 2, h - h % 2
    except Exception:
        pass
    return 1366, 640


def write_json(path, data):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


class Recorder(threading.Thread):
    """Launches the browser, records everything, builds the evidence doc on close."""

    def __init__(self, exec_dir: Path, meta: dict, script=None):
        super().__init__(daemon=True, name=f"recorder-{meta['id']}")
        self.dir = exec_dir
        self.meta = meta
        self.script = script                 # optional callable(page) used by --selftest
        self.stop_event = threading.Event()
        self.events = []
        self.step = 0
        self.last_action = ""
        self._cdp = {}
        self._pages = []
        (self.dir / "screenshots").mkdir(parents=True, exist_ok=True)
        (self.dir / "dom").mkdir(exist_ok=True)
        (self.dir / "video").mkdir(exist_ok=True)
        self._events_fh = open(self.dir / "events.jsonl", "a", encoding="utf-8")

    # ------------------------------------------------------------------ status
    def save_meta(self, **updates):
        self.meta.update(updates)
        write_json(self.dir / "meta.json", self.meta)

    def live(self):
        d = dict(self.meta)
        d["steps"] = self.step
        d["last_action"] = self.last_action
        return d

    def stop(self):
        self.stop_event.set()

    # ------------------------------------------------------------------ main
    def run(self):
        started = time.time()
        try:
            with sync_playwright() as p:
                browser, label = self._launch(p)
                self.save_meta(browser=f"{label} {browser.version}")
                try:
                    context, page = self._open_context(browser, video=True)
                except Exception as e:
                    if "ffmpeg" not in str(e).lower():
                        raise
                    self._log({"kind": "error", "ts": self._now(),
                               "message": "Screen recording unavailable (video encoder ffmpeg missing). Screenshots, data and DOM were captured."})
                    context, page = self._open_context(browser, video=False)
                try:
                    page.goto(self.meta["url"], wait_until="domcontentloaded", timeout=60000)
                except Exception as e:  # keep the browser open, tester may fix the URL
                    self._log({"kind": "error", "message": f"Could not open URL: {e}".splitlines()[0], "ts": self._now()})
                if self.script:
                    try:
                        self.script(page)
                    except Exception:
                        traceback.print_exc()
                self._loop(browser, context)
                videos = self._close(browser, context)
            self._events_fh.close()
            self.save_meta(status="generating", steps=self.step, videos=videos,
                           ended=datetime.now().isoformat(timespec="seconds"),
                           duration_sec=int(time.time() - started))
            from report import build_report
            self.save_meta(progress="Building the evidence document...")
            doc = build_report(self.dir, self.meta, self._sorted_events())
            self.save_meta(doc=doc)
            self._compare()
            self.save_meta(status="completed", progress=None)
        except Exception as e:
            traceback.print_exc()
            try:
                self._events_fh.close()
            except Exception:
                pass
            self.save_meta(status="failed", error=str(e).splitlines()[0] if str(e) else repr(e),
                           steps=self.step, ended=datetime.now().isoformat(timespec="seconds"),
                           duration_sec=int(time.time() - started))

    def _compare(self):
        """Re-execution of an earlier test case: build the old-vs-new comparison document."""
        base = self.meta.get("baseline_id")
        if not base:
            return
        old_dir = self.dir.parent / base
        if not (old_dir / "events.jsonl").exists():
            self.save_meta(comparison_error="Baseline execution not found.")
            return
        self.save_meta(progress="Comparing with the previous execution...")
        try:
            from compare import build_comparison
            res = build_comparison(self.dir, self.meta, self._sorted_events(), old_dir)
            self.save_meta(comparison=res["file"], changes=res["total"], comparison_counts=res["counts"])
        except Exception as e:
            traceback.print_exc()
            self.save_meta(comparison_error=f"Comparison failed: {str(e).splitlines()[0] if str(e) else repr(e)}")

    def _open_context(self, browser, video):
        kw = dict(no_viewport=True, accept_downloads=True)
        if video:
            w, h = screen_size()
            kw.update(record_video_dir=str(self.dir / "video"), record_video_size={"width": w, "height": h})
        context = browser.new_context(**kw)
        try:
            context.add_init_script(path=str(CAPTURE_JS))
            context.expose_binding("__caRecord", self._on_binding)
            context.on("page", self._attach)
            page = context.new_page()
        except Exception:
            try:
                context.close()
            except Exception:
                pass
            raise
        self._attach(page)
        return context, page

    def _launch(self, p):
        errors = []
        for channel, label in CHANNELS:
            try:
                kw = dict(headless=False, args=["--start-maximized"], ignore_default_args=["--enable-automation"])
                if channel:
                    kw["channel"] = channel
                return p.chromium.launch(**kw), label
            except Exception as e:
                errors.append(f"{label}: {str(e).splitlines()[0]}")
        raise RuntimeError("No supported browser found (Edge/Chrome). " + " | ".join(errors))

    def _loop(self, browser, context):
        while not self.stop_event.is_set():
            pages = [pg for pg in context.pages if not pg.is_closed()]
            if not pages or not browser.is_connected():
                break
            try:
                pages[0].wait_for_timeout(250)    # lets Playwright dispatch events
            except Exception:
                pass

    def _close(self, browser, context):
        try:
            context.close()                       # finalises the videos
        except Exception:
            pass
        slug = slugify(self.meta["tc_name"])
        videos = []
        for i, pg in enumerate(self._pages, 1):
            if not pg.video:
                continue
            name = f"{slug}_recording.webm" if len(self._pages) == 1 else f"{slug}_recording_{i}.webm"
            dst = self.dir / "video" / name
            try:
                src = Path(pg.video.path())
            except Exception:
                src = None
            try:
                # save_as waits until ffmpeg has finished writing. When the tester closes the
                # window, finalisation happens asynchronously, so never read the file directly.
                pg.video.save_as(str(dst))
            except Exception as e:
                print(f"[recorder] video save failed: {str(e).splitlines()[0]}")
            if dst.exists() and dst.stat().st_size > 0:
                videos.append(f"video/{name}")
                if src and src.exists() and src != dst:
                    try:
                        src.unlink()
                    except Exception:
                        pass
            elif src and src.exists() and src.stat().st_size > 0:   # fall back to the raw file
                src.replace(dst)
                videos.append(f"video/{name}")
        for leftover in (self.dir / "video").glob("page@*.webm"):
            try:
                if leftover.stat().st_size == 0:
                    leftover.unlink()
            except Exception:
                pass
        try:
            browser.close()
        except Exception:
            pass
        return videos

    # ------------------------------------------------------------------ pages
    def _attach(self, page):
        if page in self._pages:
            return
        self._pages.append(page)
        page.on("close", lambda: self._cdp.pop(page, None))

    # ------------------------------------------------------------------ capture
    def _on_binding(self, source, payload):
        try:
            if not isinstance(payload, dict):
                return None
            kind = payload.get("kind")
            if kind == "input":
                el = payload.get("element") or {}
                self.last_action = f"Entered '{payload.get('value', '')}' in {el.get('name', '')}"[:160]
                self._log({"kind": "input", "action": payload.get("action"), "element": el,
                           "value": payload.get("value", ""), "url": payload.get("url"),
                           "title": payload.get("title"), "ts": payload.get("ts") or self._now()})
                return None
            if kind == "snapshot":
                return self._snapshot(source["page"], payload)
        except Exception:
            traceback.print_exc()
        return None

    def _snapshot(self, page, payload):
        self.step += 1                          # reserve number before any I/O
        n = self.step
        shot_rel = f"screenshots/step_{n:03d}.jpg"
        dom_rel = f"dom/step_{n:03d}.html"
        ok = self._screenshot(page, self.dir / shot_rel)
        try:
            (self.dir / dom_rel).write_text(payload.get("dom") or "", encoding="utf-8")
        except Exception:
            dom_rel = None
        ev = {"kind": "snapshot", "step": n, "action": payload.get("action"),
              "element": payload.get("element"), "url": payload.get("url"), "title": payload.get("title"),
              "ts": payload.get("ts") or self._now(), "screenshot": shot_rel if ok else None, "dom": dom_rel}
        self.last_action = describe_step(ev)
        self._log(ev)
        return n

    def _screenshot(self, page, path: Path):
        try:
            cdp = self._cdp.get(page)
            if cdp is None:
                cdp = page.context.new_cdp_session(page)
                self._cdp[page] = cdp
            data = cdp.send("Page.captureScreenshot", {"format": "jpeg", "quality": 80})["data"]
            path.write_bytes(base64.b64decode(data))
            return True
        except Exception:
            try:
                page.screenshot(path=str(path), type="jpeg", quality=80, timeout=3000)
                return True
            except Exception:
                return False

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def _now():
        return int(time.time() * 1000)

    def _log(self, ev):
        self.events.append(ev)
        try:
            self._events_fh.write(json.dumps(ev, ensure_ascii=False) + "\n")
            self._events_fh.flush()
        except Exception:
            pass

    def _sorted_events(self):
        return sorted(self.events, key=lambda e: (e.get("ts") or 0, e.get("step") or 0))


def describe_step(ev):
    el = ev.get("element") or {}
    name = el.get("name") or ""
    action = ev.get("action")
    if action == "load":
        return f"Page loaded - {ev.get('title') or ev.get('url')}"
    if action == "enter":
        return f"Pressed Enter on '{name}'"
    return f"Clicked {el.get('actionType') or el.get('tag') or 'element'} '{name}'"


def new_meta(exec_id, tc_name, url, baseline_id=None):
    return {
        "id": exec_id, "tc_name": tc_name, "url": url, "status": "recording",
        "started": datetime.now().isoformat(timespec="seconds"), "ended": None, "duration_sec": None,
        "steps": 0, "browser": "", "tester": getpass.getuser(), "machine": platform.node(),
        "doc": None, "videos": [], "error": None,
        "baseline_id": baseline_id, "comparison": None, "changes": None,
    }
