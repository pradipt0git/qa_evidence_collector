"""Capture Assist - builds the Word evidence document (python-docx)."""
from datetime import datetime
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

ACCENT = "1F3A5F"
LABEL_BG = "E8EEF5"
IMG_WIDTH = Inches(7.0)


def _fmt_ts(ms):
    try:
        return datetime.fromtimestamp(ms / 1000).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return ""


def _fmt_dur(sec):
    if sec is None:
        return ""
    m, s = divmod(int(sec), 60)
    h, m = divmod(m, 60)
    return f"{h}h {m:02d}m {s:02d}s" if h else f"{m}m {s:02d}s"


def _shade(cell, hex_color):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tc_pr.append(shd)


def _cell_text(cell, text, bold=False, color=None, size=9):
    cell.text = ""
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    run = p.add_run("" if text is None else str(text))
    run.font.size = Pt(size)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def _kv_table(doc, rows, label_width=Inches(1.6)):
    rows = [(k, v) for k, v in rows if v not in (None, "")]
    t = doc.add_table(rows=len(rows), cols=2)
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    t.columns[0].width, t.columns[1].width = label_width, IMG_WIDTH - label_width
    for i, (k, v) in enumerate(rows):
        a, b = t.rows[i].cells
        a.width, b.width = label_width, IMG_WIDTH - label_width
        _cell_text(a, k, bold=True, color=ACCENT)
        _shade(a, LABEL_BG)
        _cell_text(b, v)
    return t


def _grid_table(doc, header, rows, widths=None):
    t = doc.add_table(rows=1 + len(rows), cols=len(header))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for j, h in enumerate(header):
        c = t.rows[0].cells[j]
        _cell_text(c, h, bold=True, color="FFFFFF")
        _shade(c, ACCENT)
    for i, row in enumerate(rows, 1):
        for j, v in enumerate(row):
            _cell_text(t.rows[i].cells[j], v)
    if widths:
        t.autofit = False
        for j, w in enumerate(widths):
            t.columns[j].width = w
        for row in t.rows:
            for j, w in enumerate(widths):
                row.cells[j].width = w
    return t


def _hyperlink(paragraph, target, text):
    r_id = paragraph.part.relate_to(target, RT.HYPERLINK, is_external=True)
    link = OxmlElement("w:hyperlink")
    link.set(qn("r:id"), r_id)
    run = OxmlElement("w:r")
    rpr = OxmlElement("w:rPr")
    color = OxmlElement("w:color")
    color.set(qn("w:val"), "1F5FBF")
    u = OxmlElement("w:u")
    u.set(qn("w:val"), "single")
    sz = OxmlElement("w:sz")
    sz.set(qn("w:val"), "18")
    rpr.extend([color, u, sz])
    run.append(rpr)
    t = OxmlElement("w:t")
    t.text = text
    run.append(t)
    link.append(run)
    paragraph._p.append(link)


def _step_title(ev):
    from recorder import describe_step
    return describe_step(ev)


def build_report(exec_dir: Path, meta: dict, events: list) -> str:
    doc = Document()
    sec = doc.sections[0]
    sec.left_margin = sec.right_margin = Inches(0.6)
    sec.top_margin = sec.bottom_margin = Inches(0.6)
    normal = doc.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(10)

    # footer
    fp = sec.footer.paragraphs[0]
    fp.text = f"Capture Assist  |  {meta['tc_name']}  |  Execution {meta['id']}"
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for r in fp.runs:
        r.font.size = Pt(8)
        r.font.color.rgb = RGBColor(0x88, 0x88, 0x88)

    # ---- title & summary
    title = doc.add_heading(meta["tc_name"], 0)
    title.alignment = WD_ALIGN_PARAGRAPH.LEFT
    sub = doc.add_paragraph()
    run = sub.add_run("Test Execution Evidence")
    run.font.size = Pt(12)
    run.font.color.rgb = RGBColor.from_string(ACCENT)

    snaps = [e for e in events if e.get("kind") == "snapshot"]
    inputs = [e for e in events if e.get("kind") == "input"]
    _kv_table(doc, [
        ("Test Case", meta["tc_name"]),
        ("Launch URL", meta["url"]),
        ("Execution ID", meta["id"]),
        ("Tester", meta.get("tester")),
        ("Machine", meta.get("machine")),
        ("Browser", meta.get("browser")),
        ("Started", (meta.get("started") or "").replace("T", " ")),
        ("Ended", (meta.get("ended") or "").replace("T", " ")),
        ("Duration", _fmt_dur(meta.get("duration_sec"))),
        ("Screenshots", str(len(snaps))),
        ("Data entries", str(len(inputs))),
        ("Screen recording", ", ".join(Path(v).name for v in meta.get("videos") or []) or "Not available"),
    ])
    if meta.get("videos"):
        p = doc.add_paragraph("Recording: ")
        p.paragraph_format.space_before = Pt(6)
        for v in meta["videos"]:
            _hyperlink(p, v, Path(v).name)
            p.add_run("   ")
    for e in events:
        if e.get("kind") == "error":
            doc.add_paragraph().add_run("Note: " + e.get("message", "")).italic = True

    # ---- steps
    doc.add_heading("Execution Steps", 1)
    pending = []
    for ev in events:
        if ev.get("kind") == "input":
            pending.append(ev)
            continue
        if ev.get("kind") != "snapshot":
            continue
        el = ev.get("element") or {}
        doc.add_heading(f"Step {ev['step']}: {_step_title(ev)}", 2)
        rows = [
            ("Time", _fmt_ts(ev.get("ts"))),
            ("Page title", ev.get("title")),
            ("Page URL", ev.get("url")),
        ]
        if el:
            tag = "<" + el.get("tag", "") + (f' type="{el["type"]}"' if el.get("type") else "") + ">"
            rows += [
                ("Element name", el.get("name")),
                ("Element type", f"{el.get('actionType', '')}   {tag}" if el.get("actionType") else tag),
                ("Element ID", el.get("id")),
                ("Name attribute", el.get("nameAttr")),
                ("Role", el.get("role")),
                ("Link target", el.get("href")),
                ("CSS selector", el.get("css")),
                ("XPath", el.get("xpath")),
                ("Frame", el.get("frame")),
            ]
        _kv_table(doc, rows)
        if pending:
            cap = doc.add_paragraph()
            cap.paragraph_format.space_before = Pt(8)
            cap.paragraph_format.space_after = Pt(4)
            cap.paragraph_format.keep_with_next = True
            cap.add_run("Data entered / selected before this step").bold = True
            _grid_table(doc, ["Field", "Action", "Value", "Time"],
                        [((p.get("element") or {}).get("name", ""), p.get("action", ""), p.get("value", ""),
                          _fmt_ts(p.get("ts"))[-8:]) for p in pending],
                        widths=[Inches(2.2), Inches(0.9), Inches(3.0), Inches(0.9)])
            pending = []
        if ev.get("screenshot") and (exec_dir / ev["screenshot"]).exists():
            pic = doc.add_paragraph()
            pic.paragraph_format.space_before = Pt(6)
            pic.alignment = WD_ALIGN_PARAGRAPH.CENTER
            pic.add_run().add_picture(str(exec_dir / ev["screenshot"]), width=IMG_WIDTH)
        if ev.get("dom"):
            p = doc.add_paragraph("DOM snapshot: ")
            p.runs[0].font.size = Pt(9)
            _hyperlink(p, ev["dom"].replace("\\", "/"), ev["dom"])

    if pending:
        doc.add_heading("Data entered after the last screenshot", 2)
        _grid_table(doc, ["Field", "Action", "Value", "Time"],
                    [((p.get("element") or {}).get("name", ""), p.get("action", ""), p.get("value", ""),
                      _fmt_ts(p.get("ts"))[-8:]) for p in pending],
                    widths=[Inches(2.2), Inches(0.9), Inches(3.0), Inches(0.9)])

    # ---- appendix: chronological log
    doc.add_page_break()
    doc.add_heading("Appendix: Interaction Log", 1)
    log_rows = []
    for ev in events:
        el = ev.get("element") or {}
        if ev.get("kind") == "snapshot":
            log_rows.append((_fmt_ts(ev.get("ts"))[-8:], f"Step {ev['step']}", _step_title(ev), ev.get("url", "")))
        elif ev.get("kind") == "input":
            log_rows.append((_fmt_ts(ev.get("ts"))[-8:], ev.get("action", ""),
                             f"{el.get('name', '')} = {ev.get('value', '')}", ev.get("url", "")))
    _grid_table(doc, ["Time", "Type", "Detail", "URL"], log_rows,
                widths=[Inches(0.8), Inches(0.8), Inches(3.0), Inches(2.4)])

    name = f"{_safe(meta['tc_name'])}_Evidence.docx"
    doc.save(str(exec_dir / name))
    return name


def _safe(text):
    from recorder import slugify
    return slugify(text)
