/* Capture Assist - injected into every page/frame of the recorded browser.
 * Records interactions, captures DOM synchronously, and gates clicks until the
 * "before" screenshot has been taken (only if the screenshot is not yet done). */
(() => {
  if (window.__caInstalled) return;
  window.__caInstalled = true;

  const MASK = '********';
  const GATE_TIMEOUT_MS = 1500;
  const isTop = (() => { try { return window.top === window; } catch (e) { return false; } })();

  const send = (payload) => {
    try {
      if (typeof window.__caRecord === 'function') return window.__caRecord(payload);
    } catch (e) { /* binding not ready */ }
    return Promise.resolve(null);
  };

  // ---------- element description ----------
  const clean = (s, n = 120) => (s || '').replace(/\s+/g, ' ').trim().slice(0, n);

  const cssEscape = (s) => (window.CSS && CSS.escape) ? CSS.escape(s) : String(s).replace(/[^a-zA-Z0-9_-]/g, '\\$&');

  function cssPath(el) {
    if (!(el instanceof Element)) return '';
    const parts = [];
    while (el && el.nodeType === 1 && parts.length < 8) {
      if (el.id) { parts.unshift('#' + cssEscape(el.id)); break; }
      let part = el.tagName.toLowerCase();
      const parent = el.parentElement;
      if (parent) {
        const same = Array.from(parent.children).filter(c => c.tagName === el.tagName);
        if (same.length > 1) part += ':nth-of-type(' + (same.indexOf(el) + 1) + ')';
      }
      parts.unshift(part);
      el = parent;
    }
    return parts.join(' > ');
  }

  function xPath(el) {
    if (!(el instanceof Element)) return '';
    if (el.id) return '//*[@id="' + el.id + '"]';
    const parts = [];
    while (el && el.nodeType === 1) {
      let i = 1;
      for (let s = el.previousElementSibling; s; s = s.previousElementSibling) if (s.tagName === el.tagName) i++;
      parts.unshift(el.tagName.toLowerCase() + '[' + i + ']');
      el = el.parentElement;
    }
    return '/' + parts.join('/');
  }

  function labelText(el) {
    try {
      if (el.labels && el.labels.length) return clean(el.labels[0].innerText);
      const lb = el.getAttribute && el.getAttribute('aria-labelledby');
      if (lb) {
        const t = lb.split(/\s+/).map(id => document.getElementById(id)).filter(Boolean).map(n => n.innerText).join(' ');
        if (t) return clean(t);
      }
      const wrap = el.closest && el.closest('label');
      if (wrap) return clean(wrap.innerText);
    } catch (e) {}
    return '';
  }

  function describe(el) {
    const tag = el.tagName ? el.tagName.toLowerCase() : '';
    const type = (el.getAttribute && el.getAttribute('type')) || '';
    const isField = /^(input|select|textarea)$/.test(tag);
    const text = isField ? '' : clean(el.innerText || el.textContent, 80);
    const name =
      clean(el.getAttribute && el.getAttribute('aria-label')) || labelText(el) || text ||
      clean(el.getAttribute && el.getAttribute('placeholder')) || clean(el.getAttribute && el.getAttribute('title')) ||
      clean(el.getAttribute && el.getAttribute('alt')) || (isField && /^(submit|button|reset)$/i.test(type) ? clean(el.value) : '') ||
      clean(el.getAttribute && el.getAttribute('name')) || el.id || tag;
    let rect = null;
    try { const r = el.getBoundingClientRect(); rect = { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) }; } catch (e) {}
    return {
      name, tag, type, id: el.id || '', nameAttr: (el.getAttribute && el.getAttribute('name')) || '',
      role: (el.getAttribute && el.getAttribute('role')) || '', text,
      href: (el.getAttribute && el.getAttribute('href')) || '',
      css: cssPath(el), xpath: xPath(el), rect, frame: isTop ? '' : location.href,
    };
  }

  // ---------- values ----------
  const isPassword = (el) => el && el.tagName === 'INPUT' && (el.type || '').toLowerCase() === 'password';

  function valueOf(el) {
    const tag = el.tagName;
    if (tag === 'SELECT') {
      const opts = Array.from(el.selectedOptions || []).map(o => clean(o.text) + (o.value && o.value !== o.text ? ' [' + o.value + ']' : ''));
      return opts.join(', ');
    }
    if (tag === 'INPUT') {
      const t = (el.type || '').toLowerCase();
      if (t === 'password') return el.value ? MASK : '';
      if (t === 'checkbox' || t === 'radio') return el.checked ? 'Checked' + (el.value && el.value !== 'on' ? ' (' + el.value + ')' : '') : 'Unchecked';
      if (t === 'file') return Array.from(el.files || []).map(f => f.name).join(', ');
      return el.value;
    }
    if (tag === 'TEXTAREA') return el.value;
    if (el.isContentEditable) return clean(el.innerText, 2000);
    return '';
  }

  // ---------- DOM snapshot (exact state at capture time) ----------
  function snapshotDOM() {
    try {
      const live = document.documentElement;
      const clone = live.cloneNode(true);
      const sel = 'input, textarea, select';
      const a = live.querySelectorAll(sel), b = clone.querySelectorAll(sel);
      for (let i = 0; i < a.length && i < b.length; i++) {
        const s = a[i], d = b[i];
        if (s.tagName === 'INPUT') {
          const t = (s.type || '').toLowerCase();
          if (t === 'checkbox' || t === 'radio') { s.checked ? d.setAttribute('checked', '') : d.removeAttribute('checked'); }
          else if (t !== 'file') d.setAttribute('value', t === 'password' ? (s.value ? MASK : '') : s.value);
        } else if (s.tagName === 'TEXTAREA') {
          d.textContent = s.value;
        } else if (s.tagName === 'SELECT') {
          const so = s.options, dop = d.options;
          for (let j = 0; j < so.length && j < dop.length; j++) so[j].selected ? dop[j].setAttribute('selected', '') : dop[j].removeAttribute('selected');
        }
      }
      // neutralise scripts so the saved file is a static snapshot; drop the recorder's own overlay
      clone.querySelectorAll('script, ca-overlay').forEach(s => s.remove());
      let head = clone.querySelector('head');
      if (!head) { head = document.createElement('head'); clone.insertBefore(head, clone.firstChild); }
      const base = document.createElement('base');
      base.setAttribute('href', document.baseURI);
      head.insertBefore(base, head.firstChild);
      const dt = document.doctype ? '<!DOCTYPE ' + document.doctype.name + '>' : '<!DOCTYPE html>';
      return dt + '\n<!-- Captured by Capture Assist at ' + new Date().toISOString() + ' from ' + location.href + ' -->\n' + clone.outerHTML;
    } catch (e) {
      return '<!-- DOM capture failed: ' + e + ' -->';
    }
  }

  // ---------- input tracking ----------
  const pending = new Map(); // element -> true (value typed but not yet recorded)
  const lastSent = new WeakMap();

  function recordValue(el, how) {
    const v = valueOf(el);
    if (lastSent.get(el) === v && how !== 'toggle') return;
    lastSent.set(el, v);
    pending.delete(el);
    send({ kind: 'input', action: how, element: describe(el), value: v, url: location.href, title: document.title, ts: Date.now() });
  }

  function flushPending() {
    for (const el of Array.from(pending.keys())) recordValue(el, 'typed');
  }

  const isField = (el) => el && el.tagName && (/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName) || el.isContentEditable);

  document.addEventListener('input', (e) => {
    const el = e.composedPath()[0];
    if (isField(el)) {
      const t = (el.type || '').toLowerCase();
      if (el.tagName === 'SELECT' || t === 'checkbox' || t === 'radio' || t === 'file' || t === 'range' || t === 'color' || t === 'date' || t === 'time' || t === 'datetime-local' || t === 'month' || t === 'week') return; // handled by change
      pending.set(el, true);
    }
  }, true);

  document.addEventListener('change', (e) => {
    const el = e.composedPath()[0];
    if (!isField(el)) return;
    const t = (el.type || '').toLowerCase();
    const how = el.tagName === 'SELECT' ? 'selected' : (t === 'checkbox' || t === 'radio') ? 'toggle' : t === 'file' ? 'uploaded' : 'typed';
    recordValue(el, how);
  }, true);

  document.addEventListener('blur', (e) => {
    const el = e.composedPath()[0];
    if (el && el.isContentEditable && pending.has(el)) recordValue(el, 'typed');
  }, true);

  // ---------- actionable detection ----------
  const ACTION_SEL = 'a[href], button, summary, label, select, option, [role=button], [role=link], [role=tab], [role=menuitem], [role=option], [role=checkbox], [role=radio], [role=switch], [onclick], input[type=submit], input[type=button], input[type=reset], input[type=image], input[type=checkbox], input[type=radio], input[type=file]';

  function actionable(target) {
    if (!(target instanceof Element)) return null;
    const hit = target.closest(ACTION_SEL);
    if (hit) {
      if (hit.tagName === 'LABEL') {
        const c = hit.control;
        if (!c || !(c.tagName === 'INPUT' && /^(checkbox|radio|submit|button|file)$/i.test(c.type))) return null;
      }
      return hit;
    }
    // generic clickable divs/spans styled as pointer
    let el = target;
    for (let i = 0; el && i < 4; i++, el = el.parentElement) {
      try { if (getComputedStyle(el).cursor === 'pointer') return el; } catch (e) { break; }
    }
    return null;
  }

  function actionLabel(el) {
    const tag = el.tagName.toLowerCase();
    const t = (el.getAttribute('type') || '').toLowerCase();
    if (tag === 'a') return 'link';
    if (tag === 'select') return 'dropdown';
    if (tag === 'input' && (t === 'checkbox' || t === 'radio')) return t;
    if (tag === 'button' || /^(submit|button|reset|image)$/.test(t)) return 'button';
    return el.getAttribute('role') || tag;
  }

  // ---------- click gate ----------
  let gate = null;       // {el, promise, done}
  let replaying = false;

  function snapshot(kind, el, extra) {
    flushPending();
    clearClicks();          // never let an earlier click marker appear in an evidence screenshot
    const payload = Object.assign({
      kind: 'snapshot', action: kind, element: el ? describe(el) : null,
      dom: snapshotDOM(), url: location.href, title: document.title, ts: Date.now(),
    }, extra || {});
    if (el) payload.element.actionType = actionLabel(el);
    return send(payload);
  }

  document.addEventListener('pointerdown', (e) => {
    if (!e.isTrusted || e.button !== 0) return;
    const x = e.clientX, y = e.clientY;
    const el = actionable(e.composedPath()[0]);
    if (!el) { showClick(x, y); return; }
    const g = { el, done: false };
    g.promise = Promise.resolve(snapshot('click', el)).catch(() => null).finally(() => { g.done = true; });
    gate = g;
    // marker is drawn right after the "before" screenshot, so screenshots stay clean
    g.promise.then(() => showClick(x, y));
  }, true);

  document.addEventListener('click', (e) => {
    if (replaying || !e.isTrusted) return;
    const g = gate;
    if (!g || g.done) return;
    const target = e.composedPath()[0];
    if (!(target instanceof Element) || !(g.el === target || g.el.contains(target) || target.contains(g.el))) return;
    // Screenshot still in flight: hold this click, then replay it.
    e.preventDefault();
    e.stopImmediatePropagation();
    const timeout = new Promise(r => setTimeout(r, GATE_TIMEOUT_MS));
    Promise.race([g.promise, timeout]).then(() => {
      replaying = true;
      try { target.click(); } finally { replaying = false; }
    });
  }, true);

  // Keyboard triggered actions (Enter submits / activates, Space on buttons)
  document.addEventListener('keydown', (e) => {
    if (!e.isTrusted) return;
    const el = e.composedPath()[0];
    if (!(el instanceof Element)) return;
    if (e.key === 'Enter') {
      if (el.tagName === 'TEXTAREA' || el.isContentEditable) return;
      if (el.tagName === 'INPUT' || actionable(el)) snapshot('enter', el);
    } else if (e.key === ' ' && actionable(el) && el.tagName !== 'INPUT') {
      snapshot('click', el);
    }
  }, true);

  // record final values before the page goes away
  window.addEventListener('pagehide', () => flushPending(), true);

  // ---------- visual cues for the screen recording ----------
  // Drawn in an isolated shadow-DOM layer: no effect on the page's styles or layout,
  // never receives clicks (pointer-events:none) and is removed from DOM snapshots.
  let ovHost = null, ovRoot = null, focusBox = null, focusEl = null, rafId = 0, lastRect = '';
  const OV_CSS =
    ':host{all:initial}' +
    '.ring{position:fixed;width:46px;height:46px;margin:-23px 0 0 -23px;border-radius:50%;box-sizing:border-box;' +
    'border:3px solid rgba(239,68,68,.95);background:rgba(239,68,68,.16);animation:ca-ring .8s ease-out forwards}' +
    '.dot{position:fixed;width:10px;height:10px;margin:-5px 0 0 -5px;border-radius:50%;background:rgba(239,68,68,.95);' +
    'animation:ca-dot .8s ease-out forwards}' +
    '@keyframes ca-ring{0%{transform:scale(.35);opacity:1}100%{transform:scale(1.55);opacity:0}}' +
    '@keyframes ca-dot{0%,65%{opacity:1}100%{opacity:0}}' +
    '.focus{position:fixed;display:none;box-sizing:border-box;border:2px solid #f59e0b;border-radius:5px;' +
    'box-shadow:0 0 0 3px rgba(245,158,11,.28)}';

  function overlayRoot() {
    if (ovHost && ovHost.isConnected) return ovRoot;
    try {
      ovHost = document.createElement('ca-overlay');
      ovHost.style.cssText = 'all:initial;position:fixed;left:0;top:0;width:0;height:0;overflow:visible;pointer-events:none;z-index:2147483647';
      ovRoot = ovHost.attachShadow({ mode: 'closed' });
      ovRoot.innerHTML = '<style>' + OV_CSS + '</style><div class="focus"></div>';
      focusBox = ovRoot.querySelector('.focus');
      document.documentElement.appendChild(ovHost);
      return ovRoot;
    } catch (e) { return null; }
  }

  function showClick(x, y) {
    const root = overlayRoot();
    if (!root) return;
    const ring = document.createElement('div'); ring.className = 'ring';
    const dot = document.createElement('div'); dot.className = 'dot';
    ring.style.left = dot.style.left = x + 'px';
    ring.style.top = dot.style.top = y + 'px';
    root.append(ring, dot);
    setTimeout(() => { ring.remove(); dot.remove(); }, 850);
  }

  function clearClicks() {
    if (ovRoot) ovRoot.querySelectorAll('.ring, .dot').forEach((n) => n.remove());
  }

  function hideFocus() {
    focusEl = null; lastRect = '';
    cancelAnimationFrame(rafId);
    if (focusBox) focusBox.style.display = 'none';
  }

  function trackFocus() {
    cancelAnimationFrame(rafId);
    const tick = () => {
      if (!focusEl || !focusEl.isConnected || document.activeElement === document.body) return hideFocus();
      const r = focusEl.getBoundingClientRect();
      const key = r.left + ',' + r.top + ',' + r.width + ',' + r.height;
      if (key !== lastRect) {          // only touch the overlay when the element moved/resized
        lastRect = key;
        if (r.width === 0 && r.height === 0) focusBox.style.display = 'none';
        else Object.assign(focusBox.style, { display: 'block', left: (r.left - 4) + 'px', top: (r.top - 4) + 'px',
                                              width: (r.width + 8) + 'px', height: (r.height + 8) + 'px' });
      }
      rafId = requestAnimationFrame(tick);
    };
    tick();
  }

  document.addEventListener('focusin', (e) => {
    const el = e.composedPath()[0];
    if (!(el instanceof Element) || el === document.body || el === document.documentElement || el.tagName === 'IFRAME') return;
    if (!overlayRoot()) return;
    focusEl = el; lastRect = '';
    trackFocus();
  }, true);
  document.addEventListener('focusout', () => {
    setTimeout(() => { const a = document.activeElement; if (!a || a === document.body || a.tagName === 'IFRAME') hideFocus(); }, 0);
  }, true);

  // "page loaded" snapshot (top document only), shortly after load so late rendering is included
  if (isTop) {
    const onLoad = () => setTimeout(() => snapshot('load', null), 600);
    if (document.readyState === 'complete') onLoad(); else window.addEventListener('load', onLoad, { once: true });
  }
})();
